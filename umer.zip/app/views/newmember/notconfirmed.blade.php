<div class="not-confirmed-wrapper">
  <div class="not-confirmed">
    <span class="not-confirmed__button" id="confirm-user-mail"><i class="fa fa-envelope-o"></i> {{Lang::get('profilepage.send_again')}}</span>
    <p class="not-confirmed__string">{{Lang::get('profilepage.message_to_you')}}</p>
    <p class="not-confirmed__string">{{Lang::get('profilepage.if_havent_message')}}</p>
  </div>
</div>
