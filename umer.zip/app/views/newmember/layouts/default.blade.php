@include('newmember.layouts.header')
@yield('content')
@include('newmember.layouts.footer')
