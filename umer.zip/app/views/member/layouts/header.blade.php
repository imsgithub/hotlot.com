<!doctype html>
<html lang="ru">
    <head>
        <meta charset="UTF-8">
        <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
        <link rel="stylesheet" href="/evth/public/css/memberstyle.css">
        <link rel="stylesheet" href="/evth/public/css/jquery.datetimepicker.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
        <script src="/evth/public/js/jquery.js"></script>
        <script src="/evth/public/js/jquery.datetimepicker.js"></script>
        <script src="/evth/public/js/burger.js"></script>
        @yield('meta')
    </head>
    <body>

    </body>
</html>

