<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body style="margin: 0; padding: 0;">
<style type="text/css">
	#outlook a {padding:0;}
	body{width:100% !important; -webkit-text-size-adjust:100%; -ms-text-size-adjust:100%; margin:0; padding:0;} 
	.ExternalClass {width:100%;}
	.ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div {line-height: 100%;}
	img {outline:none; text-decoration:none; -ms-interpolation-mode: bicubic;} 
	a img {border:none;} 
	p {margin:0 0 1em 0;}
	table td {border-collapse: collapse;}
	table { border-collapse:collapse; mso-table-lspace:0pt; mso-table-rspace:0pt; }
</style>
<table width="600" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td align="left" style="color:#553074; font-family: Arial, Helvetica, sans-serif; font-size: 20px; padding:10px">Новая заявка на сайте <strong>rate-and-go.com</strong>!</td>
	</tr>
	<tr>
		<td align="left" style="color:#553074; font-family: Arial, Helvetica, sans-serif; font-size: 20px; padding:10px">Откуда - {{$from}}</td>
	</tr>
        <tr>
		<td align="left" style="color:#553074; font-family: Arial, Helvetica, sans-serif; font-size: 20px; padding:10px">Куда - {{$where}}</td>
	</tr>
	<tr>
		<td align="left" style="color:#553074; font-family: Arial, Helvetica, sans-serif; font-size: 20px; padding:10px">Телефон - <a style="color:#e16f0e;" href="tel:{{$phone}}">{{$phone}}</a></td>
	</tr>
	<tr>
		<td height="10"></td>
	</tr>	
</table>
</body>
