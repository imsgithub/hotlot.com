@include('admin.layouts.header')
<div class="inner">
@include('admin.layouts.sidebar')


@yield('content')
</div>
@include('admin.layouts.footer')
