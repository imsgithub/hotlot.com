@extends('admin.layouts.default')
@section('content')        
<p>Администратор</p>

@stop