@extends('admin.layouts.default')
@section('content')
<h4 class="title">Отказано в доступе</h4>
@stop
