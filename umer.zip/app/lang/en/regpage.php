<?php
return[
	'go' => 'Sign in',
	'email' => 'Enter your email',
	'password' => 'Enter your password',
	'forgot pass' => 'Forgot your password',
	'login' => 'Login',
	'' => '',
	'' => '',
	'' => '',
	'' => '',
	'' => ''
];