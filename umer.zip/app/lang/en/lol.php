<?php

return array(
    'home'=>'English page',
    'content'=>'Content on english page'
);
