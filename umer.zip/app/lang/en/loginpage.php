<?php
return[
	'go' => 'Sign in',
	'email' => 'Enter your email',
	'password' => 'Enter your password',
	'forgot_pass' => 'Forgot your password',
	'login' => 'Login',
	'' => '',
	'' => '',
	'' => '',
	'' => '',
	'' => ''
];