<?php
return[
	'title_rem' => 'Восстановление пароля',
	'clear_pass' => 'Сброс пароля',
	'enter_email' => 'Введите email',
	'reset_pass' => 'Восстановить пароль',
	
	'title_new' => 'Новый пароль',
	'change_pass' => 'Изменить пароль',
	'you_email' => 'Введите ваш email',
	'new_pass' => 'Ваш новый пароль',
	'pass_repeat' => 'Пароль еще раз',
	'change_pass_but' => 'Сменить пароль',
	'' => '',
	'' => '',
	'' => '',
];