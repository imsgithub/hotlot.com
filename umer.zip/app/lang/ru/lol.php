<?php

return array(
    'home'=>'Русская страница',
    'content'=>'Контент на русской странице'
);
