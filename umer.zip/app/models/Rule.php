<?php

class Rule extends Eloquent {
    protected $table = 'rules';
    public $timestamps = false;
//    public function coeffs() {
//        return $this-;
//    }
}