<?php

class Currency extends Eloquent {
    protected $table = 'currencies';
    public $timestamps = false;    
}