<?php

class UaArea extends Eloquent {
    protected $table = 'ua_areas';
    public $timestamps = false;
    protected $fillable = ['name'];
}

